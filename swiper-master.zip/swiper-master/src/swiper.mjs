export { default as Swiper, default } from './core/core.mjs';
